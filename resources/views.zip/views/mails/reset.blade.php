<!DOCTYPE html>
<html>

<head>
    <title>Reset Password</title>
</head>

<body>
    <h1>Untuk mereset password kamu, silahkan klik link berikut:</h1>
    <a href="{{ $data['link'] }}">Klik disini</a>
</body>

</html>
